---
title: Chapter 1: The Beginning
status: draft
label: none
---

It was a dark and stormy night...